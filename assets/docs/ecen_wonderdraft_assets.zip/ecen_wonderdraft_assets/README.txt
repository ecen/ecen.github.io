Copyright (c) 2018 Eric Guldbrand

You may use, copy, modify and redistribute all files according 
to the terms and conditions of the Creative Commons Attribution 4.0
International License. See the file `LICENSE-CC-BY.txt` for details.

If you for some reason need this library under another license you
may contact me. You can find contact details at eric.guldbrand.io.

:)
